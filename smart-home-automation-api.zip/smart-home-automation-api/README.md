
# Smart Home Automation API (FastAPI)

A teach-by-doing project demonstrating CRUD APIs, authentication, scheduling, and Swagger documentation for a Smart Home domain.

## Tech
- FastAPI (auto Swagger at `/docs` and `/redoc`)
- SQLite + SQLAlchemy
- JWT auth (register/login)
- APScheduler for simple schedules (cron-like)
- Modular routers: rooms, devices, scenes, schedules

## Quickstart

```bash
# 1) Create virtual env (example for Linux/Mac)
python -m venv .venv
source .venv/bin/activate

# 1b) On Windows PowerShell
# py -m venv .venv
# .\.venv\Scripts\Activate.ps1

# 2) Install deps
pip install -r requirements.txt

# 3) Set environment (optional; defaults in code)
export SECRET_KEY="change-me-please"
export ACCESS_TOKEN_EXPIRE_MINUTES=120

# 4) Run API
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs for interactive Swagger UI.

## Postman
In Postman: *Import* ➜ *Link* ➜ enter `http://127.0.0.1:8000/openapi.json` to auto-generate a collection.

## Default Flow to Demo on Video
1. Register a user ➜ Login ➜ copy JWT.
2. Create a Room ➜ Create a Device in that Room.
3. Toggle Device state.
4. Create a Scene referencing multiple device states, then `apply` the Scene.
5. Create a Schedule with a cron (e.g., every minute) that triggers the Scene (watch device states change).

