
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import Base, engine
from app.routers import auth as auth_router
from app.routers import rooms as rooms_router
from app.routers import devices as devices_router
from app.routers import scenes as scenes_router
from app.routers import schedules as schedules_router
from app.services.scheduler import reload_all_jobs

# create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Smart Home Automation API",
    version="1.0.0",
    description="CRUD APIs for rooms, devices, scenes, and schedules. JWT auth. Auto docs via Swagger UI.",
)

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router.router)
app.include_router(rooms_router.router)
app.include_router(devices_router.router)
app.include_router(scenes_router.router)
app.include_router(schedules_router.router)

@app.on_event("startup")
def on_startup():
    # ensure in-memory scheduler jobs match DB
    reload_all_jobs()

@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "docs": "/docs"}
