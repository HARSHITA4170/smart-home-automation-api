
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Text, Enum
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.types import JSON
import enum

from app.core.database import Base

class DeviceType(str, enum.Enum):
    light = "light"
    fan = "fan"
    ac = "ac"
    plug = "plug"
    sensor = "sensor"

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

class Room(Base):
    __tablename__ = "rooms"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)

    devices = relationship("Device", back_populates="room", cascade="all, delete")

class Device(Base):
    __tablename__ = "devices"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    type: Mapped[DeviceType] = mapped_column(Enum(DeviceType), nullable=False)
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False)
    is_on: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    properties: Mapped[dict] = mapped_column(JSON, default=dict)

    room = relationship("Room", back_populates="devices")

class Scene(Base):
    __tablename__ = "scenes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    # device_states: [{device_id: int, is_on: bool, properties: {}}]
    device_states: Mapped[list] = mapped_column(JSON, default=list)

class Schedule(Base):
    __tablename__ = "schedules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    cron: Mapped[str] = mapped_column(String(100), nullable=False)  # crontab format, e.g. */1 * * * *
    target_type: Mapped[str] = mapped_column(String(20), nullable=False)  # 'scene' or 'device'
    target_id: Mapped[int] = mapped_column(Integer, nullable=False)
    action: Mapped[str] = mapped_column(String(20), nullable=True)  # e.g., 'on', 'off', or None for scene apply
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

class EventLog(Base):
    __tablename__ = "event_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    level: Mapped[str] = mapped_column(String(10), default="INFO")
    message: Mapped[str] = mapped_column(Text, nullable=False)
    context: Mapped[dict] = mapped_column(JSON, default=dict)
