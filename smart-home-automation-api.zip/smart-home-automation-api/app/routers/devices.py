
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.core.database import get_db
from app.models.models import Device, Room, DeviceType
from app.schemas.schemas import DeviceCreate, DeviceUpdate, DeviceOut, DeviceStateUpdate
from app.services.auth import get_current_user

router = APIRouter(prefix="/api/v1/devices", tags=["Devices"])

@router.post("", response_model=DeviceOut, status_code=201)
def create_device(device_in: DeviceCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    room = db.get(Room, device_in.room_id)
    if not room:
        raise HTTPException(status_code=400, detail="Invalid room_id")
    device = Device(name=device_in.name, type=DeviceType(device_in.type), room_id=device_in.room_id, properties=device_in.properties or {})
    db.add(device)
    db.commit()
    db.refresh(device)
    return device

@router.get("", response_model=List[DeviceOut])
def list_devices(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Device).all()

@router.get("/{device_id}", response_model=DeviceOut)
def get_device(device_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return device

@router.patch("/{device_id}", response_model=DeviceOut)
def update_device(device_id: int, device_in: DeviceUpdate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    if device_in.name is not None:
        device.name = device_in.name
    if device_in.room_id is not None:
        device.room_id = device_in.room_id
    if device_in.properties is not None:
        device.properties = device_in.properties
    db.commit()
    db.refresh(device)
    return device

@router.delete("/{device_id}", status_code=204)
def delete_device(device_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    db.delete(device)
    db.commit()
    return

@router.patch("/{device_id}/state", response_model=DeviceOut)
def set_device_state(device_id: int, update: DeviceStateUpdate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    device.is_on = update.is_on
    if update.properties is not None:
        # merge/update properties
        props = device.properties or {}
        props.update(update.properties)
        device.properties = props
    db.commit()
    db.refresh(device)
    return device
