
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.core.database import get_db
from app.models.models import Room
from app.schemas.schemas import RoomCreate, RoomOut
from app.services.auth import get_current_user

router = APIRouter(prefix="/api/v1/rooms", tags=["Rooms"])

@router.post("", response_model=RoomOut, status_code=201)
def create_room(room_in: RoomCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    if db.query(Room).filter(Room.name == room_in.name).first():
        raise HTTPException(status_code=400, detail="Room name already exists")
    room = Room(name=room_in.name, description=room_in.description)
    db.add(room)
    db.commit()
    db.refresh(room)
    return room

@router.get("", response_model=List[RoomOut])
def list_rooms(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Room).all()

@router.get("/{room_id}", response_model=RoomOut)
def get_room(room_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    room = db.get(Room, room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    return room

@router.delete("/{room_id}", status_code=204)
def delete_room(room_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    room = db.get(Room, room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    db.delete(room)
    db.commit()
    return
