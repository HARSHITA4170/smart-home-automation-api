
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.core.database import get_db
from app.models.models import Scene, Device
from app.schemas.schemas import SceneCreate, SceneOut
from app.services.auth import get_current_user

router = APIRouter(prefix="/api/v1/scenes", tags=["Scenes"])

@router.post("", response_model=SceneOut, status_code=201)
def create_scene(scene_in: SceneCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    # validate referenced devices exist
    device_ids = [item.get("device_id") for item in scene_in.device_states]
    valid_count = db.query(Device).filter(Device.id.in_(device_ids)).count()
    if valid_count != len(device_ids):
        raise HTTPException(status_code=400, detail="One or more device_ids are invalid")
    scene = Scene(name=scene_in.name, device_states=scene_in.device_states)
    db.add(scene)
    db.commit()
    db.refresh(scene)
    return scene

@router.get("", response_model=List[SceneOut])
def list_scenes(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Scene).all()

@router.get("/{scene_id}", response_model=SceneOut)
def get_scene(scene_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    scene = db.get(Scene, scene_id)
    if not scene:
        raise HTTPException(status_code=404, detail="Scene not found")
    return scene

@router.post("/{scene_id}/apply", response_model=SceneOut)
def apply_scene(scene_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    scene = db.get(Scene, scene_id)
    if not scene:
        raise HTTPException(status_code=404, detail="Scene not found")
    # apply device states
    for ds in scene.device_states:
        dev = db.get(Device, ds.get("device_id"))
        if dev:
            dev.is_on = bool(ds.get("is_on", dev.is_on))
            props = dev.properties or {}
            props.update(ds.get("properties") or {})
            dev.properties = props
    db.commit()
    db.refresh(scene)
    return scene
