
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from apscheduler.triggers.cron import CronTrigger

from app.core.database import get_db, SessionLocal
from app.models.models import Schedule, Device, Scene
from app.schemas.schemas import ScheduleCreate, ScheduleUpdate, ScheduleOut
from app.services.auth import get_current_user
from app.services.scheduler import scheduler, schedule_job, remove_job, reload_all_jobs

router = APIRouter(prefix="/api/v1/schedules", tags=["Schedules"])

@router.post("", response_model=ScheduleOut, status_code=201)
def create_schedule(s_in: ScheduleCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    # validate target
    if s_in.target_type == "scene":
        if not db.get(Scene, s_in.target_id):
            raise HTTPException(status_code=400, detail="Invalid scene id")
    elif s_in.target_type == "device":
        if not db.get(Device, s_in.target_id):
            raise HTTPException(status_code=400, detail="Invalid device id")
    else:
        raise HTTPException(status_code=400, detail="Invalid target_type")

    # validate cron
    try:
        CronTrigger.from_crontab(s_in.cron)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid cron: {e}")

    sch = Schedule(name=s_in.name, cron=s_in.cron, target_type=s_in.target_type, target_id=s_in.target_id, action=s_in.action, enabled=s_in.enabled)
    db.add(sch)
    db.commit()
    db.refresh(sch)

    if sch.enabled:
        schedule_job(sch)
    return sch

@router.get("", response_model=List[ScheduleOut])
def list_schedules(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Schedule).all()

@router.patch("/{schedule_id}", response_model=ScheduleOut)
def update_schedule(schedule_id: int, s_upd: ScheduleUpdate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    sch = db.get(Schedule, schedule_id)
    if not sch:
        raise HTTPException(status_code=404, detail="Schedule not found")

    if s_upd.cron is not None:
        from apscheduler.triggers.cron import CronTrigger
        try:
            CronTrigger.from_crontab(s_upd.cron)
            sch.cron = s_upd.cron
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid cron: {e}")
    if s_upd.enabled is not None:
        sch.enabled = s_upd.enabled
    if s_upd.action is not None:
        sch.action = s_upd.action

    db.commit()
    db.refresh(sch)

    # re-schedule
    remove_job(sch.id)
    if sch.enabled:
        schedule_job(sch)
    return sch

@router.delete("/{schedule_id}", status_code=204)
def delete_schedule(schedule_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    sch = db.get(Schedule, schedule_id)
    if not sch:
        raise HTTPException(status_code=404, detail="Schedule not found")
    db.delete(sch)
    db.commit()
    remove_job(schedule_id)
    return

@router.post("/reload", status_code=200)
def reload_jobs(db: Session = Depends(get_db), user=Depends(get_current_user)):
    reload_all_jobs()
    return {"status": "reloaded"}
