
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Literal, Any

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6)

class UserOut(BaseModel):
    id: int
    email: EmailStr
    class Config:
        from_attributes = True

class RoomCreate(BaseModel):
    name: str
    description: Optional[str] = None

class RoomOut(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    class Config:
        from_attributes = True

class DeviceBase(BaseModel):
    name: str
    type: Literal["light", "fan", "ac", "plug", "sensor"]
    room_id: int
    properties: dict = {}

class DeviceCreate(DeviceBase):
    pass

class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    room_id: Optional[int] = None
    properties: Optional[dict] = None

class DeviceOut(BaseModel):
    id: int
    name: str
    type: str
    room_id: int
    is_on: bool
    properties: dict
    class Config:
        from_attributes = True

class DeviceStateUpdate(BaseModel):
    is_on: bool
    properties: Optional[dict] = None

class SceneCreate(BaseModel):
    name: str
    device_states: List[dict]  # [{"device_id":1, "is_on":true, "properties": {...}}, ...]

class SceneOut(BaseModel):
    id: int
    name: str
    device_states: List[dict]
    class Config:
        from_attributes = True

class ScheduleCreate(BaseModel):
    name: str
    cron: str  # e.g., */1 * * * *
    target_type: Literal["scene", "device"]
    target_id: int
    action: Optional[Literal["on", "off"]] = None
    enabled: bool = True

class ScheduleUpdate(BaseModel):
    cron: Optional[str] = None
    enabled: Optional[bool] = None
    action: Optional[Literal["on", "off"]] = None

class ScheduleOut(BaseModel):
    id: int
    name: str
    cron: str
    target_type: str
    target_id: int
    action: Optional[str] = None
    enabled: bool
    class Config:
        from_attributes = True

class LogOut(BaseModel):
    id: int
    timestamp: Any
    level: str
    message: str
    context: dict
    class Config:
        from_attributes = True
