
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.models.models import Schedule, Scene, Device

scheduler = BackgroundScheduler(timezone="UTC")
scheduler.start()

def _execute_schedule(schedule_id: int):
    db: Session = SessionLocal()
    try:
        sch = db.get(Schedule, schedule_id)
        if not sch or not sch.enabled:
            return
        if sch.target_type == "scene":
            scene = db.get(Scene, sch.target_id)
            if scene:
                # apply scene
                for ds in scene.device_states:
                    dev = db.get(Device, ds.get("device_id"))
                    if dev:
                        dev.is_on = bool(ds.get("is_on", dev.is_on))
                        props = dev.properties or {}
                        props.update(ds.get("properties") or {})
                        dev.properties = props
                db.commit()
        elif sch.target_type == "device":
            dev = db.get(Device, sch.target_id)
            if dev and sch.action in ("on", "off"):
                dev.is_on = (sch.action == "on")
                db.commit()
    finally:
        db.close()

def schedule_job(sch: Schedule):
    trigger = CronTrigger.from_crontab(sch.cron)
    scheduler.add_job(_execute_schedule, trigger=trigger, args=[sch.id], id=f"schedule_{sch.id}", replace_existing=True)

def remove_job(schedule_id: int):
    job_id = f"schedule_{schedule_id}"
    try:
        scheduler.remove_job(job_id)
    except Exception:
        pass

def reload_all_jobs():
    # Load all schedules and (re)register jobs
    db = SessionLocal()
    try:
        for sch in db.query(Schedule).all():
            remove_job(sch.id)
            if sch.enabled:
                schedule_job(sch)
    finally:
        db.close()
